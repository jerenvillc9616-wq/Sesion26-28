#!/usr/bin/env python3
"""
lua53_to_luau_v3.py — Token-aware Lua 5.3 → Luau converter.

Uses a proper Lua tokenizer to find function boundaries reliably,
then converts each function body's gotos to a state machine.
"""

import re
import sys
import os

# ============================================================================
# Token-based Lua block tracker
# ============================================================================

# Lua keywords that open a block
OPENERS = {'function', 'if', 'for', 'while', 'do', 'repeat'}
# Lua keywords/tokens that close a block
CLOSERS_END = {'end'}      # closes function, if, for, while, do
CLOSERS_UNTIL = {'until'}  # closes repeat

class LuaTokenizer:
    """Simple Lua tokenizer that handles strings and comments correctly."""
    
    def __init__(self, source):
        self.src = source
        self.pos = 0
        self.len = len(source)
    
    def tokenize(self):
        """Yield (kind, value, start_pos, end_pos) tuples."""
        while self.pos < self.len:
            ch = self.src[self.pos]
            
            # Whitespace
            if ch in ' \t\n\r':
                start = self.pos
                while self.pos < self.len and self.src[self.pos] in ' \t\n\r':
                    self.pos += 1
                yield ('ws', self.src[start:self.pos], start, self.pos)
                continue
            
            # Long comment: --[[ ... ]] or --[=[ ... ]=]
            if self.src[self.pos:self.pos+2] == '--':
                start = self.pos
                self.pos += 2
                # Check for long bracket
                if self.pos < self.len and self.src[self.pos] == '[':
                    eq = 0
                    p = self.pos + 1
                    while p < self.len and self.src[p] == '=':
                        eq += 1
                        p += 1
                    if p < self.len and self.src[p] == '[':
                        # Long comment
                        self.pos = p + 1
                        end_marker = ']' + '=' * eq + ']'
                        end_idx = self.src.find(end_marker, self.pos)
                        if end_idx == -1:
                            self.pos = self.len
                        else:
                            self.pos = end_idx + len(end_marker)
                        yield ('comment', self.src[start:self.pos], start, self.pos)
                        continue
                # Line comment
                while self.pos < self.len and self.src[self.pos] != '\n':
                    self.pos += 1
                yield ('comment', self.src[start:self.pos], start, self.pos)
                continue
            
            # Long string: [[ ... ]] or [=[ ... ]=]
            if ch == '[':
                p = self.pos + 1
                eq = 0
                while p < self.len and self.src[p] == '=':
                    eq += 1
                    p += 1
                if p < self.len and self.src[p] == '[':
                    start = self.pos
                    self.pos = p + 1
                    end_marker = ']' + '=' * eq + ']'
                    end_idx = self.src.find(end_marker, self.pos)
                    if end_idx == -1:
                        self.pos = self.len
                    else:
                        self.pos = end_idx + len(end_marker)
                    yield ('string', self.src[start:self.pos], start, self.pos)
                    continue
            
            # Quoted string
            if ch in '"\'':
                start = self.pos
                quote = ch
                self.pos += 1
                while self.pos < self.len:
                    c = self.src[self.pos]
                    if c == '\\':
                        self.pos += 2
                        continue
                    if c == quote:
                        self.pos += 1
                        break
                    if c == '\n':
                        # Unterminated string
                        break
                    self.pos += 1
                yield ('string', self.src[start:self.pos], start, self.pos)
                continue
            
            # Number
            if ch.isdigit() or (ch == '.' and self.pos+1 < self.len and self.src[self.pos+1].isdigit()):
                start = self.pos
                # Handle hex
                if ch == '0' and self.pos+1 < self.len and self.src[self.pos+1] in 'xX':
                    self.pos += 2
                    while self.pos < self.len and (self.src[self.pos].isalnum() or self.src[self.pos] == '.'):
                        self.pos += 1
                else:
                    while self.pos < self.len and (self.src[self.pos].isdigit() or self.src[self.pos] == '.'):
                        self.pos += 1
                    if self.pos < self.len and self.src[self.pos] in 'eE':
                        self.pos += 1
                        if self.pos < self.len and self.src[self.pos] in '+-':
                            self.pos += 1
                        while self.pos < self.len and self.src[self.pos].isdigit():
                            self.pos += 1
                yield ('number', self.src[start:self.pos], start, self.pos)
                continue
            
            # Identifier / keyword
            if ch.isalpha() or ch == '_':
                start = self.pos
                while self.pos < self.len and (self.src[self.pos].isalnum() or self.src[self.pos] == '_'):
                    self.pos += 1
                word = self.src[start:self.pos]
                if word in OPENERS or word in CLOSERS_END or word in CLOSERS_UNTIL or word in {'then', 'elseif', 'else', 'return', 'local', 'in'}:
                    yield ('keyword', word, start, self.pos)
                else:
                    yield ('ident', word, start, self.pos)
                continue
            
            # Operators / punctuation
            # Multi-char first
            two = self.src[self.pos:self.pos+2]
            if two in ('==', '~=', '<=', '>=', '<<', '>>', '..', '::', '//'):
                yield ('op', two, self.pos, self.pos + 2)
                self.pos += 2
                continue
            
            # Single char
            yield ('op', ch, self.pos, self.pos + 1)
            self.pos += 1


def find_function_blocks(source):
    """Return list of (start_pos, end_pos) for each top-level and nested function block.
    
    A 'function block' here means: from the 'function' keyword (after = or local)
    to its matching 'end'.
    """
    tokenizer = LuaTokenizer(source)
    tokens = list(tokenizer.tokenize())
    
    # Filter out whitespace and comments for structural analysis
    # but keep their positions
    structural = [(i, t) for i, t in enumerate(tokens) if t[0] not in ('ws', 'comment', 'string', 'number')]
    
    function_blocks = []
    
    # Walk through tokens and track block stack
    # When we see 'function', push 'function' onto stack
    # When we see other openers, push them
    # When we see 'end' or 'until', pop
    
    stack = []  # (kind, token_index, source_pos)
    
    for i, (kind, value, start, end) in enumerate(tokens):
        if kind == 'keyword':
            if value == 'function':
                stack.append(('function', i, start))
            elif value == 'if':
                stack.append(('if', i, start))
            elif value == 'for':
                stack.append(('for', i, start))
            elif value == 'while':
                stack.append(('while', i, start))
            elif value == 'do':
                # 'do' might close a 'for' or 'while' (then opens its own block)
                # Or it might be a standalone 'do ... end' block
                if stack and stack[-1][0] in ('for', 'while'):
                    # for/while ... do — keep stack frame, just mark we're past 'do'
                    pass  # the outer for/while frame stays
                else:
                    # standalone do block
                    stack.append(('do', i, start))
            elif value == 'repeat':
                stack.append(('repeat', i, start))
            elif value == 'then':
                # closes the 'if'/'elseif' header, body starts now
                pass
            elif value == 'end':
                if stack:
                    block = stack.pop()
                    if block[0] == 'function':
                        function_blocks.append((block[2], end))
            elif value == 'until':
                if stack and stack[-1][0] == 'repeat':
                    stack.pop()
    
    return function_blocks


# ============================================================================
# Conversion logic (same as v2 but using better function detection)
# ============================================================================

def replace_bitwise(code):
    """Replace Lua 5.3 bitwise operators with bit32 calls."""
    lines = code.split('\n')
    out = []
    for line in lines:
        if line.lstrip().startswith('--'):
            out.append(line)
            continue
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*<<\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.lshift(\1, \2)', line)
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*>>\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.rshift(\1, \2)', line)
        line = re.sub(r'=\s*~(\w+)\s*$', r'= bit32.bnot(\1)', line)
        line = re.sub(r',\s*~(\w+)', r', bit32.bnot(\1)', line)
        line = re.sub(r'(\b\w+)\s*~\s*(?!=)(\b\w+)', r'bit32.bxor(\1, \2)', line)
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*&\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.band(\1, \2)', line)
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*\|\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.bor(\1, \2)', line)
        out.append(line)
    return '\n'.join(out)


def convert_function_body(func_text):
    """Convert a single function body's gotos to a state machine.
    
    func_text starts with 'function' keyword and ends with matching 'end'.
    """
    if 'goto L' not in func_text and '::L' not in func_text:
        return func_text
    
    # Find the function header end (the ')' after parameters, then optional whitespace)
    # We need to find where the body starts
    paren_count = 0
    body_start = -1
    in_func_header = False
    
    for i, ch in enumerate(func_text):
        if ch == '(' and not in_func_header:
            in_func_header = True
            paren_count = 1
        elif in_func_header:
            if ch == '(':
                paren_count += 1
            elif ch == ')':
                paren_count -= 1
                if paren_count == 0:
                    body_start = i + 1
                    break
    
    if body_start == -1:
        return func_text
    
    header = func_text[:body_start]
    
    # Find the last 'end' (which closes the function)
    # Use tokenizer to find it correctly
    body_with_end = func_text[body_start:]
    
    # The body ends at the function's closing 'end'
    # Since we got func_text as already-balanced, the last 'end' is ours
    # But we need to find it correctly with tokens (not in strings/comments)
    
    # Simple approach: tokenize the body and find the last 'end'
    tok = LuaTokenizer(body_with_end)
    tokens = list(tok.tokenize())
    
    # Track depth: body starts at depth 0
    depth = 0
    last_end_pos = -1
    
    for kind, value, start, end in tokens:
        if kind == 'keyword':
            if value in ('function', 'if', 'for', 'while', 'repeat'):
                depth += 1
            elif value == 'do':
                # Only count standalone do
                # For/while do is part of the outer block
                # Heuristic: check if previous non-ws token was 'for' or 'while'
                # Simpler: just count all 'do' as +1
                depth += 1
            elif value == 'end':
                if depth > 0:
                    depth -= 1
                else:
                    # This is the function's closing 'end'
                    last_end_pos = start
                    break
            elif value == 'until':
                depth -= 1
    
    if last_end_pos == -1:
        return func_text
    
    body_only = body_with_end[:last_end_pos]
    closing = body_with_end[last_end_pos:]  # should be 'end' + maybe trailing
    
    # Now convert gotos in body_only
    new_body = goto_to_state_machine(body_only, header)
    
    return header + new_body + closing


def goto_to_state_machine(body, header):
    """Convert goto/label patterns in a function body to a state machine."""
    if 'goto L' not in body and '::L' not in body:
        return body
    
    lines = body.split('\n')
    
    # Find indent
    base_indent = '    '
    for line in lines:
        s = line.strip()
        if s and not s.startswith('--'):
            base_indent = line[:len(line) - len(line.lstrip())]
            break
    
    # Find local declarations and pre-control code
    # Pre-control = everything before first label/goto
    first_ctrl = -1
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith('--'):
            continue
        if re.match(r'^::L\d+::$', s) or re.search(r'\bgoto L\d+\b', s):
            first_ctrl = i
            break
    
    if first_ctrl == -1:
        return body
    
    pre_lines = lines[:first_ctrl]
    ctrl_lines = lines[first_ctrl:]
    
    # Build state list
    states = []
    current_state = "_entry"
    current_body = []
    
    for line in ctrl_lines:
        s = line.strip()
        label_m = re.match(r'^::L(\d+)::$', s)
        if label_m:
            states.append((current_state, current_body))
            current_state = f"L{label_m.group(1)}"
            current_body = []
            continue
        current_body.append(line)
    
    states.append((current_state, current_body))
    
    # Emit state machine
    out_lines = list(pre_lines)
    out_lines.append(f"{base_indent}local _st = \"_entry\"")
    out_lines.append(f"{base_indent}while true do")
    
    indent2 = base_indent + '  '
    indent3 = indent2 + '  '
    
    first = True
    for si, (sname, sbody) in enumerate(states):
        kw = "if" if first else "elseif"
        first = False
        out_lines.append(f"{indent2}{kw} _st == \"{sname}\" then")
        
        for line in sbody:
            converted = convert_line(line, indent3)
            out_lines.append(converted)
        
        # Fallthrough handling
        if sbody:
            last = sbody[-1].strip()
            ends_with_jump = (
                re.match(r'^goto L\d+\s*$', last) or
                last.startswith('return') or
                re.match(r'^do\s+return\b.*\bend\s*$', last) or
                re.search(r'goto L\d+\s*end\s*$', last)
            )
            if not ends_with_jump and si + 1 < len(states):
                out_lines.append(f"{indent3}_st = \"{states[si+1][0]}\"")
        elif si + 1 < len(states):
            out_lines.append(f"{indent3}_st = \"{states[si+1][0]}\"")
    
    out_lines.append(f"{indent2}else")
    out_lines.append(f"{indent3}break")
    out_lines.append(f"{indent2}end")
    out_lines.append(f"{base_indent}end")
    
    return '\n'.join(out_lines)


def convert_line(line, indent):
    """Convert a single line, handling goto patterns."""
    s = line.strip()
    if not s:
        return ""
    if s.startswith('--'):
        return line
    
    # Pure goto: "goto Lxx"
    m = re.match(r'^goto (L\d+)$', s)
    if m:
        return f"{indent}_st = \"{m.group(1)}\"; continue"
    
    # Conditional goto: "if COND then goto Lxx end"
    m = re.match(r'^if (.+) then goto (L\d+) end$', s)
    if m:
        return f"{indent}if {m.group(1)} then _st = \"{m.group(2)}\"; continue end"
    
    # Combined conditional: "if COND then STMT; goto Lxx end"
    m = re.match(r'^if (.+) then (.+?);\s*goto (L\d+) end$', s)
    if m:
        return f"{indent}if {m.group(1)} then {m.group(2)}; _st = \"{m.group(3)}\"; continue end"
    
    # Combined: "STMT; if COND then ASSIGN; goto Lxx end"
    m = re.match(r'^(.+?);\s*if (.+) then (.+?);\s*goto (L\d+) end$', s)
    if m:
        return f"{indent}{m.group(1)}; if {m.group(2)} then {m.group(3)}; _st = \"{m.group(4)}\"; continue end"
    
    # Inline: "STMT; goto Lxx"
    m = re.match(r'^(.+?);\s*goto (L\d+)$', s)
    if m:
        return f"{indent}{m.group(1)}; _st = \"{m.group(2)}\"; continue"
    
    # Trailing goto without semicolon: "STMT goto Lxx"
    m = re.match(r'^(.+?)\s+goto (L\d+)$', s)
    if m and 'then' not in m.group(1) and not m.group(1).strip().endswith('do') and not m.group(1).strip().endswith('then'):
        return f"{indent}{m.group(1)}; _st = \"{m.group(2)}\"; continue"
    
    # Default
    return f"{indent}{s}"


def convert_file(input_path, output_path):
    with open(input_path, 'r') as f:
        code = f.read().replace('\r\n', '\n')
    
    orig_gotos = len(re.findall(r'\bgoto L\d+\b', code))
    orig_labels = len(re.findall(r'::L\d+::', code))
    orig_env_str = len(re.findall(r'_ENV\["[^"]+"\]', code))
    orig_env_var = len(re.findall(r'_ENV\[\w+\]', code))
    
    print(f"[input]  {os.path.basename(input_path)}:")
    print(f"  {orig_gotos} gotos, {orig_labels} labels, "
          f"{orig_env_str} _ENV[str], {orig_env_var} _ENV[var]")
    
    # Phase 1: Replace _ENV
    code = re.sub(r'_ENV\["(\w+)"\]', r'\1', code)
    code = re.sub(r'_ENV\[(\w+)\]', r'getfenv()[\1]', code)
    
    # Phase 2: Replace bitwise ops
    code = replace_bitwise(code)
    
    # Phase 3: io stubs
    code = re.sub(r'\bio\.write\b\([^)]*\)', '-- io.write removed', code)
    code = re.sub(r'\bio\.read\b\([^)]*\)', '""', code)
    
    # Phase 4: Header
    code = code.replace('-- Lua 5.3,', '-- [Luau] converted from Lua 5.3,', 1)
    
    # Phase 5: Find function blocks and convert each
    print("  Tokenizing & finding functions...")
    func_blocks = find_function_blocks(code)
    print(f"  Found {len(func_blocks)} function blocks")
    
    # Process from innermost outward (sort by start position descending so 
    # we process inner functions first, which doesn't shift outer positions)
    # Actually we need outermost first if we replace text... 
    # Use position-based approach: collect all blocks, then reconstruct
    
    # Sort by start position; process outer functions first; the conversion
    # is per-function so nested functions get processed when their parent
    # is processed.
    
    # Simpler: only convert TOP-LEVEL functions (those not nested in another
    # function block we're tracking). Then the convert_function_body recurses
    # naturally.
    
    # Actually, let's do this: process the file as a series of segments,
    # converting each function block (working from end to start to preserve
    # earlier offsets).
    
    # But nested functions need to be handled too. Let me reconsider.
    # 
    # The simplest approach: convert TOP-level functions only, but within
    # each, also recursively find nested functions.
    
    top_level = []
    for start, end in func_blocks:
        # Check if this block is contained in another
        is_nested = False
        for s2, e2 in func_blocks:
            if (s2, e2) != (start, end) and s2 < start and e2 > end:
                is_nested = True
                break
        if not is_nested:
            top_level.append((start, end))
    
    print(f"  Top-level functions: {len(top_level)}")
    
    # Process from end to start to preserve offsets
    top_level.sort(key=lambda x: -x[0])
    
    for start, end in top_level:
        func_text = code[start:end]
        if 'goto L' in func_text or '::L' in func_text:
            # Recursively convert this function (which handles nested)
            converted = convert_function_recursive(func_text)
            code = code[:start] + converted + code[end:]
    
    # Final stats
    rem_gotos = sum(1 for line in code.split('\n') 
                    if not line.strip().startswith('--') and re.search(r'\bgoto L\d+\b', line))
    rem_labels = sum(1 for line in code.split('\n')
                     if not line.strip().startswith('--') and re.match(r'^\s*::L\d+::\s*$', line))
    rem_env = code.count('_ENV[')
    
    print(f"[output] {os.path.basename(output_path)}: {rem_gotos} gotos, {rem_labels} labels, {rem_env} _ENV refs")
    
    with open(output_path, 'w') as f:
        f.write(code)
    print(f"  → {len(code):,} bytes\n")


def convert_function_recursive(func_text):
    """Recursively convert a function and any nested functions.
    
    Strategy: find IMMEDIATE child function blocks. Convert each child
    recursively (which handles its own children). Then convert this
    function's own body (with children already converted in place).
    """
    blocks = find_function_blocks(func_text)
    
    if not blocks:
        return func_text
    
    # Find the outermost block (this function itself, starts at 0)
    outer = None
    for s, e in blocks:
        if s == 0:
            outer = (s, e)
            break
    
    if outer is None:
        # The text doesn't start with 'function' — shouldn't happen
        # Just process as-is
        return convert_function_body(func_text)
    
    # Find immediate children: blocks contained in outer but not in any
    # other block (other than outer itself)
    children = []
    for s, e in blocks:
        if (s, e) == outer:
            continue
        # Find the smallest block that contains (s, e)
        smallest_container = None
        smallest_size = float('inf')
        for s2, e2 in blocks:
            if (s2, e2) == (s, e):
                continue
            if s2 <= s and e2 >= e:
                size = e2 - s2
                if size < smallest_size:
                    smallest_size = size
                    smallest_container = (s2, e2)
        # If the smallest container is the outer, this is an immediate child
        if smallest_container == outer:
            children.append((s, e))
    
    # Process children from end to start to preserve earlier offsets
    children.sort(key=lambda x: -x[0])
    
    for s, e in children:
        inner_text = func_text[s:e]
        converted = convert_function_recursive(inner_text)  # ← recursive!
        func_text = func_text[:s] + converted + func_text[e:]
    
    # Now convert this function's own body (children already replaced)
    return convert_function_body(func_text)


def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <input.lua> <output.lua>")
        print(f"       {sys.argv[0]} --batch <input_dir> <output_dir>")
        sys.exit(1)
    
    if sys.argv[1] == '--batch':
        in_dir = sys.argv[2]
        out_dir = sys.argv[3]
        os.makedirs(out_dir, exist_ok=True)
        for f in sorted(os.listdir(in_dir)):
            if f.endswith('.lua'):
                convert_file(
                    os.path.join(in_dir, f),
                    os.path.join(out_dir, f.replace('.lua', '_luau.lua'))
                )
    else:
        convert_file(sys.argv[1], sys.argv[2])


if __name__ == '__main__':
    main()
