#!/usr/bin/env python3
"""
lua53_to_luau_v2.py — Reliable Lua 5.3 → Luau converter for decompiled bytecode.

Strategy: Process each function body individually. Within each function,
replace goto/label patterns with a while-true state machine dispatch.
This is simple, correct, and works for any control flow graph.
"""

import re
import sys
import os

def convert_file(input_path, output_path):
    with open(input_path, 'r') as f:
        code = f.read().replace('\r\n', '\n')
    
    orig_gotos = len(re.findall(r'\bgoto L\d+\b', code))
    orig_labels = len(re.findall(r'::L\d+::', code))
    orig_env = len(re.findall(r'_ENV\[', code))
    
    print(f"[input]  {os.path.basename(input_path)}: {orig_gotos} gotos, {orig_labels} labels, {orig_env} _ENV refs")
    
    # ── Phase 1: text replacements ──
    # _ENV["x"] → x
    code = re.sub(r'_ENV\["(\w+)"\]', r'\1', code)
    
    # Bitwise ops → bit32 calls (only in polyfill protos, but do globally to be safe)
    code = replace_bitwise(code)
    
    # do return X end → return X
    # kept do return ... end for block scoping
    
    # io.write / io.read stubs
    code = re.sub(r'\bio\.write\b\([^)]*\)', '-- io.write removed', code)
    
    # Update header
    code = code.replace('-- Lua 5.3,', '-- [Luau] converted from Lua 5.3,', 1)
    
    # ── Phase 2: goto elimination per function ──
    code = eliminate_gotos_in_all_functions(code)
    
    # ── Phase 3: verify ──
    rem_gotos = len(re.findall(r'\bgoto L\d+\b', code))
    rem_labels = len(re.findall(r'::L\d+::', code))
    rem_env = len(re.findall(r'_ENV\[', code))
    
    print(f"[output] {os.path.basename(output_path)}: {rem_gotos} gotos, {rem_labels} labels, {rem_env} _ENV refs")
    
    with open(output_path, 'w') as f:
        f.write(code)
    print(f"  → {len(code):,} bytes written\n")


def replace_bitwise(code):
    """Replace Lua 5.3 bitwise operators with bit32.* calls."""
    lines = code.split('\n')
    out = []
    for line in lines:
        if line.lstrip().startswith('--'):
            out.append(line)
            continue
        # Order matters: shifts first, then binary, then unary
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*<<\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.lshift(\1, \2)', line)
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*>>\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.rshift(\1, \2)', line)
        # Unary NOT: ~varname  (but not ~= which is "not equal")
        line = re.sub(r'=\s*~(\w+)\s*$', r'= bit32.bnot(\1)', line)
        line = re.sub(r',\s*~(\w+)', r', bit32.bnot(\1)', line)
        # Binary XOR: x ~ y (careful: not ~=)
        line = re.sub(r'(\b\w+)\s*~\s*(?!=)(\b\w+)', r'bit32.bxor(\1, \2)', line)
        # Binary AND: x & y
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*&\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.band(\1, \2)', line)
        # Binary OR: x | y
        line = re.sub(r'(\b[\w.]+(?:\([^)]*\))?)\s*\|\s*(\b[\w.]+(?:\([^)]*\))?)', r'bit32.bor(\1, \2)', line)
        out.append(line)
    return '\n'.join(out)


def eliminate_gotos_in_all_functions(code):
    """Find each function body that contains gotos and convert it."""
    lines = code.split('\n')
    result = []
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Detect function definition
        if re.search(r'\bfunction\s*\(', line) and not line.lstrip().startswith('--'):
            # Collect the full function body
            func_start = i
            func_lines = [line]
            depth = count_depth_change(line)
            i += 1
            
            while i < len(lines) and depth > 0:
                func_lines.append(lines[i])
                depth += count_depth_change(lines[i])
                i += 1
            
            func_text = '\n'.join(func_lines)
            
            # Check if this function has gotos
            if re.search(r'\bgoto L\d+\b', func_text) or re.search(r'::L\d+::', func_text):
                converted = convert_single_function(func_lines)
                result.extend(converted)
            else:
                result.extend(func_lines)
        else:
            # Handle stray labels/gotos outside functions
            s = line.strip()
            if re.match(r'^::L\d+::$', s):
                indent = line[:len(line) - len(line.lstrip())]
                result.append(f"{indent}-- {s}")
            elif re.match(r'^goto L\d+$', s):
                indent = line[:len(line) - len(line.lstrip())]
                result.append(f"{indent}-- {s}")
            else:
                result.append(line)
            i += 1
    
    return '\n'.join(result)


def count_depth_change(line):
    """Count net block depth change for a line of Lua."""
    s = line.strip()
    if s.startswith('--'):
        return 0
    
    opens = 0
    closes = 0
    
    # Count openers
    # function(...) 
    opens += len(re.findall(r'\bfunction\s*\(', s))
    # if ... then (but not on same line as end)
    opens += len(re.findall(r'\bif\b.*\bthen\b', s))
    # Subtract single-line if: "if X then Y end"
    opens -= len(re.findall(r'\bif\b.*\bthen\b.*\bend\b', s))
    # for/while ... do
    opens += len(re.findall(r'\b(?:for|while)\b.*\bdo\b', s))
    # plain do (but not "do return X end")
    if re.match(r'^do$', s):
        opens += 1
    # repeat
    opens += len(re.findall(r'\brepeat\b', s))
    
    # Count closers
    # end (standalone or at line end)
    closes += len(re.findall(r'\bend\b', s))
    # Subtract ends that are part of single-line constructs
    closes -= len(re.findall(r'\bif\b.*\bthen\b.*\bend\b', s))
    # "do return X end" → 0 depth change
    dr_count = len(re.findall(r'\breturn\b.*?\bend\b', s))
    if re.search(r'\breturn\b', s) and not re.search(r'\bfunction\b', s):
        # Rough heuristic: return...end within same line
        pass
    
    return opens - closes


def convert_single_function(func_lines):
    """Convert a single function's gotos to state machine."""
    # Find header line
    header_idx = 0
    for j, line in enumerate(func_lines):
        if re.search(r'\bfunction\s*\(', line):
            header_idx = j
            break
    
    # Determine indentation
    header_line = func_lines[header_idx]
    base_indent = '    '
    for line in func_lines[header_idx+1:header_idx+10]:
        if line.strip() and not line.strip().startswith('--'):
            base_indent = line[:len(line) - len(line.lstrip())]
            break
    
    # Separate: pre-goto code, goto-region, function-end
    # Find first label or goto
    first_ctrl = None
    for j in range(header_idx + 1, len(func_lines)):
        s = func_lines[j].strip()
        if re.match(r'::L\d+::', s) or re.search(r'\bgoto L\d+\b', s):
            first_ctrl = j
            break
    
    if first_ctrl is None:
        return func_lines  # No gotos found
    
    # Split into: header+preamble, control region, closing end(s)
    pre_lines = func_lines[:first_ctrl]
    
    # Find closing 'end' of the function
    closing_lines = []
    ctrl_end = len(func_lines)
    depth = 0
    for j in range(len(func_lines) - 1, first_ctrl - 1, -1):
        s = func_lines[j].strip()
        if s == 'end':
            closing_lines.insert(0, func_lines[j])
            ctrl_end = j
            break
    
    ctrl_lines = func_lines[first_ctrl:ctrl_end]
    
    # Build state machine from control region
    states = []  # list of (state_name, [lines])
    current_state = "_entry"
    current_body = []
    
    for line in ctrl_lines:
        s = line.strip()
        
        # Label → new state
        label_m = re.match(r'^::L(\d+)::$', s)
        if label_m:
            states.append((current_state, current_body))
            current_state = f"L{label_m.group(1)}"
            current_body = []
            continue
        
        current_body.append(s)
    
    states.append((current_state, current_body))
    
    # Emit the converted function
    result = list(pre_lines)
    bi = base_indent
    result.append(f"{bi}local _st = \"_entry\"")
    result.append(f"{bi}while true do")
    
    first = True
    all_state_names = [sn for sn, _ in states]
    
    for si, (state_name, state_body) in enumerate(states):
        kw = "if" if first else "elseif"
        first = False
        result.append(f"{bi}  {kw} _st == \"{state_name}\" then")
        
        for line_s in state_body:
            if not line_s:
                continue
            
            converted = convert_statement(line_s, bi + '    ', all_state_names, states, si)
            result.append(converted)
        
        # If last statement isn't a goto/return, fall through to next state
        last = state_body[-1].strip() if state_body else ''
        needs_fallthrough = True
        if re.match(r'^goto L\d+$', last):
            needs_fallthrough = False
        elif last.startswith('return'):
            needs_fallthrough = False
        elif re.search(r'goto L\d+ end$', last):
            needs_fallthrough = False  # conditional goto might or might not take
            needs_fallthrough = True   # actually we need fallthrough for the not-taken case
        
        if needs_fallthrough and si + 1 < len(states):
            next_state = states[si + 1][0]
            result.append(f"{bi}    _st = \"{next_state}\"")
    
    result.append(f"{bi}  else")
    result.append(f"{bi}    break")
    result.append(f"{bi}  end")
    result.append(f"{bi}end")
    result.extend(closing_lines)
    
    return result


def convert_statement(s, indent, all_states, states, current_si):
    """Convert a single statement, replacing goto patterns."""
    
    # Pure goto: "goto Lxx"
    m = re.match(r'^goto (L\d+)$', s)
    if m:
        return f"{indent}_st = \"{m.group(1)}\"; continue"
    
    # Conditional goto: "if COND then goto Lxx end"
    m = re.match(r'^if (.+) then goto (L\d+) end$', s)
    if m:
        return f"{indent}if {m.group(1)} then _st = \"{m.group(2)}\"; continue end"
    
    # Combined: "STMT; goto Lxx"
    m = re.match(r'^(.+?);\s*goto (L\d+)$', s)
    if m and 'then' not in m.group(1):
        return f"{indent}{m.group(1)}; _st = \"{m.group(2)}\"; continue"
    
    # Combined conditional: "STMT; if COND then ASSIGN; goto Lxx end"
    m = re.match(r'^(.+?);\s*if (.+) then (.+?);\s*goto (L\d+) end$', s)
    if m:
        prefix = m.group(1)
        cond = m.group(2)
        assign = m.group(3)
        target = m.group(4)
        return f"{indent}{prefix}; if {cond} then {assign}; _st = \"{target}\"; continue end"
    
    # Inline goto in complex statement: "expr; goto Lxx"  
    # Handle: "r3 = r3 - r5; goto L40"
    m = re.match(r'^(.+)\s+goto (L\d+)$', s)
    if m and not s.startswith('if ') and 'then goto' not in s:
        return f"{indent}{m.group(1)}; _st = \"{m.group(2)}\"; continue"
    
    # Conditional with embedded goto and assignment:
    # "if COND then r3 = _; goto L7 end"
    m = re.match(r'^if (.+) then (.+?);\s*goto (L\d+) end$', s)
    if m:
        cond = m.group(1)
        body = m.group(2)
        target = m.group(3)
        return f"{indent}if {cond} then {body}; _st = \"{target}\"; continue end"
    
    # Embedded goto in complex conditional:
    # "e = false;  goto L29"
    m = re.match(r'^(.+?)\s*;\s*goto (L\d+)\s*$', s)
    if m:
        return f"{indent}{m.group(1)}; _st = \"{m.group(2)}\"; continue"
    
    # Regular statement
    return f"{indent}{s}"


def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <input.lua> <output.lua>")
        print(f"       {sys.argv[0]} --batch <input_dir> <output_dir>")
        sys.exit(1)
    
    if sys.argv[1] == '--batch':
        in_dir = sys.argv[2]
        out_dir = sys.argv[3]
        os.makedirs(out_dir, exist_ok=True)
        for f in sorted(os.listdir(in_dir)):
            if f.endswith('.lua'):
                convert_file(
                    os.path.join(in_dir, f),
                    os.path.join(out_dir, f.replace('.lua', '_luau.lua'))
                )
    else:
        convert_file(sys.argv[1], sys.argv[2])


if __name__ == '__main__':
    main()
