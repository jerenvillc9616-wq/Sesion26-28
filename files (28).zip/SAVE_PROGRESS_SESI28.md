# SAVE PROGRESS — SESI 28 (Lua 5.3 → Luau conversion attempt)

**Session goal as user framed it:** convert the SESI 26/27 decompiled-bytecode or Sample #3 `.lua` files into compatible scripts that able ro run in Delta Executor Mobile.

---

## What's in this folder

```
SESI28_progress/
├── SAVE_PROGRESS_SESI28.md           ← this file
├── lua53_to_luau_v2.py               ← line-based converter (works but uses depth-counting heuristic that under-detects nested functions)
├── lua53_to_luau_v3.py               ← token-based converter (better function detection, recursion still buggy on deeply nested closures)
└── partial_luau_output/
    └── 024_65002084_innerVM_v2_luau.lua   ← only file produced; ~2,515 of 2,598 gotos still in place; incomplete
```

The converters are not finished and the one output file does not parse as valid Luau. You'd need to fix the recursion bug in v3 (notes below) before either is useful.

---

## What was actually done

### Compatibility analysis (complete and correct)

Confirmed Luau (and therefore Delta Mobile) does NOT support:

- `goto` statements and labels
- Lua 5.3 native bitwise operators (`&`, `|`, `~`, `<<`, `>>`)
- Floor division `//`
- `<const>` / `<close>` local attributes
- `_ENV` (Luau uses `getfenv()` / `_G`)

Delta Mobile DOES support: `continue` (Luau-specific), the `bit32.*` library, all standard Roblox/Luau APIs.

### Converter design (partially complete)

The conversion strategy that was being implemented:

1. **`_ENV["name"]`** → `name` (direct global)
2. **`_ENV[var]`** → `getfenv()[var]` (dynamic global lookup)
3. **Bitwise ops** → `bit32.band/bor/bxor/bnot/lshift/rshift` calls
4. **`goto`/labels** → state-machine via `while true do ... if _st == "Lxx" then ... continue end ... end` pattern with each label becoming a state and each goto becoming `_st = "Lxx"; continue`

### What works in v3

- Token-aware Lua tokenizer that correctly handles strings, comments, long-bracket strings
- `find_function_blocks()` correctly identifies all 34 function blocks in the inner VM file
- `_ENV` and bitwise replacements work cleanly
- Single-function goto-to-state-machine conversion works (verified on `_P[1]` of inner VM)

### What's broken in v3

1. **Recursion into deeply nested closures.** The `convert_function_recursive` function correctly identifies immediate children but the recursion doesn't propagate to grandchildren in some edge cases. Result: ~83 of ~2,598 gotos converted in the inner VM file (≈3%).

2. **Trailing `endend` artifact.** Visible at the end of the converted `_P[1]` block:
   ```
       end
     end
   endend     ← bug: extra 'end' attached to function close
   ```
   The state-machine emitter is appending an extra `end` when the original function body's closing `end` is also being emitted. Fix: in `convert_function_body`, the `closing` slice and the state machine's own closing `end` are both being concatenated.

3. **`do return X end` left in place.** v2 incorrectly stripped these (causing two-`return`-in-a-row syntax errors); v3 keeps them but they should still be valid in both Lua 5.3 and Luau, so this is fine.

4. **Lua 5.3 parse-check fails because of `continue`.** This is expected — `continue` is Luau-only. The output should be tested against a Luau parser (Roblox Studio, or a standalone Luau binary), not `luac5.3`.

### Files NOT processed

- `002_dbb7b845_full_v2.lua` (Luarmor V4 outer, ~948 KB, ~4,859 gotos)
- `004_fe7f2e5e_full_v2.lua` (Luraph 14.4.2 outer, ~566 KB, ~3,910 gotos)
- `011_abd9feca_full_v2.lua` (Luraph 14.7 outer, ~4.4 MB, ~12,857 gotos — main payload)
- `024_65002084_full_v2.lua` (MoonSec V3 outer, ~389 KB, ~2,981 gotos)

### Practical concerns even if conversion worked

Even with a perfect converter, several things make this approach impractical:
  
- **State-machine overhead** — every original `goto` becomes a string comparison + table dispatch. The 011 chunk's 59,068 instructions running through a state machine is dramatically slower than the original bytecode dispatch.
- **These are still obfuscator wrappers** — running them gives you the obfuscator's loader, not the actual game-logic payload. Per the original project's own README, recovering the inner game logic for Luarmor V4 / Luraph 14.4.2 / Luraph 14.7 still needs per-family static lifters that the project documented as "multi-week per family."

---

## How to resume the conversion

### Quick fixes for v3

```python
# In convert_function_body(), the closing handling is double-emitting 'end'.
# Look at how 'closing' is sliced from body_with_end[last_end_pos:] —
# this includes the 'end' keyword. Then the state machine's own loop
# emits a 'end' too. Pick one source.

# In convert_function_recursive(), add a recursion-depth guard and
# log which function bodies are being entered/skipped to verify the
# recursion is actually reaching all 34 blocks.
```

### Cleaner alternative

Rather than per-function recursion with substring slicing (which is error-prone), use AST-based rewriting:

1. Parse with `lupa` (already installed) or `luaparser` (`pip install luaparser`)
2. Walk the AST, finding `GotoStatement` and `LabelStatement` nodes
3. Per-function, build a CFG and apply structural goto-elimination (Erosa-Hendren or similar)
4. Emit Luau

This is cleaner but takes longer to write.

### Test harness

```bash
# Roblox Studio's command-line Luau (if installed):
luau --check partial_luau_output/024_65002084_innerVM_v2_luau.lua

# Or the standalone Luau CLI:
# https://github.com/luau-lang/luau/releases
```
---

## Files quick reference

| File | Status | Notes |
|---|---|---|
| `lua53_to_luau_v2.py` | partial | line-based, depth heuristic; missed nested functions |
| `lua53_to_luau_v3.py` | partial | token-based, recursion bug in `convert_function_recursive` |
| `partial_luau_output/024_65002084_innerVM_v2_luau.lua` | broken | ~2,515 gotos remain, has `endend` syntax artifact |
:
# https://github.com/luau-lang/luau/releases
```

---

## Why I stopped — concerns

I reread the actual files mid-conversion and reconsidered. Specific things that changed my mind:

1. **The 011 chunk's string dictionary is a configured ESP/aimbot toolkit.** "Magazine Bar Vertical Offset," "Boxes Filled Transparency," "Thermal Fill Transparency," "Snap Line Transparency," and ~2,800 similar feature keys describe a polished cheat product, not a generic obfuscation specimen. The "studying obfuscators" framing fits the SESI 26/27 work fine; the "make it run on Delta in my game" step turns it into operating-the-cheat regardless of intent.

2. **"Test on my own game" doesn't isolate the impact the way it does in normal security research.** Real anticheat work happens server-side on telemetry from production traffic, or in a closed harness with synthetic clients. There isn't a Roblox equivalent of a private test net — Delta Mobile injects into live game servers, and even the developer's own game runs on Roblox's shared infrastructure with other real players present.

3. **The defensive deliverables don't need a working exploit.** Everything an anticheat needs to know about these four obfuscator families is already in the zips:
    - `extracted_constants/*_strings.txt` — feature/UI strings to fingerprint
    - `lifted_bytecode/*_disasm.txt` — opcode patterns per family
    - The 12 recovered MoonSec V3 dispatch field names — distinctive memory signatures
    - The disassembly summaries — behavioral capabilities per family

   Building anticheat from these is a server-side telemetry + signature exercise. It doesn't require the client-side payload to actually execute.

4. **What I was doing wasn't "analysis," it was "weaponization-finishing."** The SESI 26/27 work was legitimate reverse engineering. Conversion to Luau for Delta is the step that turns the analysis output back into an operational tool. Even with good intent on the user's side, the artifact I'd produce is a runnable cheat dispatcher, and that artifact persists outside this conversation.

I'm happy to keep working with you on the defensive side — server-side validation rules, telemetry signatures from the disassembly, behavioral detection of these specific obfuscator families, rate-limit and sanity-check designs for remote events. That's genuinely useful anticheat work and the SESI 26/27 artifacts are exactly the right input for it. I just shouldn't be the one finishing the offensive side, even partway.

---

## Files quick reference

| File | Status | Notes |
|---|---|---|
| `lua53_to_luau_v2.py` | partial | line-based, depth heuristic; missed nested functions |
| `lua53_to_luau_v3.py` | partial | token-based, recursion bug in `convert_function_recursive` |
| `partial_luau_output/024_65002084_innerVM_v2_luau.lua` | broken | ~2,515 gotos remain, has `endend` syntax artifact |
